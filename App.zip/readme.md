# BUILD
cd android
./gradlew assembleRelease


# START
npm start